'use strict';

const { validateExplanation, FALLBACK_TEXT } = require('../src/validation/validateExplanation');

function rankedItem({ id, price, area, noise }) {
  return {
    product_id: id,
    model_code: id,
    effective_price: price,
    matched_reasons: ['Phù hợp ngân sách.'],
    tradeoffs: [],
    missing_data: [],
    source: {
      category: 'may_lanh',
      room_area_range: area || null,
      noise_db: noise || null,
    },
  };
}

const rankingResult = {
  results: [
    rankedItem({ id: 'AC-1', price: 12_000_000, area: { min: 15, max: 20 }, noise: { min: 29, max: 45 } }),
    rankedItem({ id: 'AC-2', price: 15_000_000, area: { min: 20, max: 30 } }),
  ],
};
const state = { slots: { budget_max: 20_000_000, room_area_m2: 18 } };

describe('validateExplanation — item hợp lệ', () => {
  test('claim số đúng với dữ liệu thật -> giữ nguyên text, status ok', () => {
    const llmOutput = {
      summary: 'AC-1 phù hợp ngân sách và phòng ngủ nhỏ hơn.',
      items: [
        {
          product_id: 'AC-1',
          headline: 'Giá 12 triệu, chạy êm 29 dB, phù hợp phòng 18m²',
          pros: ['Phù hợp ngân sách 20 triệu khách đưa ra', 'Độ ồn thấp 29 dB phù hợp phòng ngủ'],
          cons: [],
          recommendation_reason: 'Rẻ hơn 3 triệu so với AC-2 mà vẫn đáp ứng đủ nhu cầu.',
        },
        {
          product_id: 'AC-2',
          headline: 'Diện tích sử dụng lớn hơn, phù hợp phòng khách',
          pros: ['Phù hợp phòng rộng hơn'],
          cons: ['Giá cao hơn lựa chọn còn lại'],
          recommendation_reason: 'Phù hợp nếu phòng lớn hơn 20m².',
        },
      ],
    };

    const result = validateExplanation(llmOutput, rankingResult, state);
    expect(result.status).toBe('ok');
    expect(result.corrections).toEqual([]);
    expect(result.items[0].headline).toBe(llmOutput.items[0].headline);
    expect(result.items[0].effective_price).toBe(12_000_000);
  });
});

describe('validateExplanation — chặn sản phẩm ngoài Top N', () => {
  test('product_id không có trong Top N -> loại bỏ item, ghi vào rejected_items', () => {
    const llmOutput = {
      items: [
        { product_id: 'AC-1', headline: 'Phù hợp ngân sách.', pros: [], cons: [], recommendation_reason: 'OK.' },
        { product_id: 'AC-BỊA-RA', headline: 'Sản phẩm không tồn tại trong catalog.', pros: [], cons: [], recommendation_reason: 'X' },
      ],
    };

    const result = validateExplanation(llmOutput, rankingResult, state);
    expect(result.rejected_items).toHaveLength(1);
    expect(result.rejected_items[0].product_id).toBe('AC-BỊA-RA');
    expect(result.items.map((i) => i.product_id)).not.toContain('AC-BỊA-RA');
  });
});

describe('validateExplanation — sửa/ẩn claim số sai lệch', () => {
  test('giá bịa ra không khớp record gốc -> field bị thay bằng fallback, ghi vào corrections', () => {
    const llmOutput = {
      items: [
        {
          product_id: 'AC-1',
          headline: 'Giá chỉ 8 triệu, siêu rẻ', // record thật là 12 triệu -> sai lệch
          pros: [],
          cons: [],
          recommendation_reason: 'Đáng mua.',
        },
        rankedResponseFor('AC-2'),
      ],
    };

    const result = validateExplanation(llmOutput, rankingResult, state);
    const item1 = result.items.find((i) => i.product_id === 'AC-1');

    expect(item1.headline).toBe(FALLBACK_TEXT);
    expect(item1.effective_price).toBe(12_000_000); // giá hiển thị vẫn lấy từ nguồn thật, không phải số LLM bịa
    expect(result.corrections.some((c) => c.product_id === 'AC-1' && c.field === 'headline')).toBe(true);
    expect(result.status).toBe('corrected');
  });

  test('thông số kỹ thuật bịa ra (độ ồn sai) -> bị thay bằng fallback', () => {
    const llmOutput = {
      items: [
        {
          product_id: 'AC-1',
          headline: 'Chạy siêu êm chỉ 10 dB', // record thật min noise là 29 dB
          pros: [],
          cons: [],
          recommendation_reason: 'OK',
        },
        rankedResponseFor('AC-2'),
      ],
    };

    const result = validateExplanation(llmOutput, rankingResult, state);
    const item1 = result.items.find((i) => i.product_id === 'AC-1');
    expect(item1.headline).toBe(FALLBACK_TEXT);
    expect(result.corrections[0].reason).toBe('unverified_numeric_claim');
  });

  test('mọi item đều bị loại/không có nội dung hợp lệ -> status blocked', () => {
    const llmOutput = { items: [{ product_id: 'SP-KHONG-TON-TAI', headline: 'x', pros: [], cons: [] }] };
    const result = validateExplanation(llmOutput, rankingResult, state);
    expect(result.status).toBe('blocked');
    expect(result.message).toBeTruthy();
  });

  test('LLM bỏ sót 1 sản phẩm trong Top N -> vẫn giữ sản phẩm đó trong output kèm cờ llm_explanation_missing', () => {
    const llmOutput = { items: [rankedResponseFor('AC-1')] };
    const result = validateExplanation(llmOutput, rankingResult, state);

    const missingOne = result.items.find((i) => i.product_id === 'AC-2');
    expect(missingOne.llm_explanation_missing).toBe(true);
    expect(missingOne.effective_price).toBe(15_000_000);
    expect(result.status).toBe('ok');
  });
});

// Helper: một item hợp lệ đơn giản không chứa claim số nào để cô lập test case đang xét.
function rankedResponseFor(productId) {
  return {
    product_id: productId,
    headline: 'Lựa chọn phù hợp.',
    pros: ['Đáp ứng nhu cầu cơ bản.'],
    cons: [],
    recommendation_reason: 'Phù hợp nhu cầu đã nêu.',
  };
}
