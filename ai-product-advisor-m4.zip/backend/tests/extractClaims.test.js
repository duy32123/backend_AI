'use strict';

const { extractMoneyMentions, extractSpecMentions } = require('../src/validation/extractClaims');

describe('extractMoneyMentions', () => {
  test('nhận diện "X triệu"', () => {
    expect(extractMoneyMentions('Giá khoảng 20 triệu, khá hợp lý')).toEqual([20_000_000]);
  });

  test('nhận diện số có dấu phân cách hàng nghìn kèm đơn vị đ/vnd', () => {
    expect(extractMoneyMentions('Giá niêm yết 14.990.000đ')).toEqual([14_990_000]);
  });

  test('nhận diện nhiều mention trong cùng 1 câu (vd câu so sánh)', () => {
    const mentions = extractMoneyMentions('Rẻ hơn 3 triệu so với model 20 triệu kia');
    expect(mentions).toEqual(expect.arrayContaining([3_000_000, 20_000_000]));
  });

  test('không có số tiền -> mảng rỗng', () => {
    expect(extractMoneyMentions('Sản phẩm chạy êm, tiết kiệm điện')).toEqual([]);
  });

  test('input không phải string -> mảng rỗng, không throw', () => {
    expect(extractMoneyMentions(null)).toEqual([]);
    expect(extractMoneyMentions(undefined)).toEqual([]);
  });
});

describe('extractSpecMentions', () => {
  test('nhận diện m², dB, lít, người trong cùng văn bản', () => {
    const mentions = extractSpecMentions('Phù hợp phòng 18m², chạy êm 29 dB, phù hợp gia đình 4 người');
    expect(mentions).toEqual(
      expect.arrayContaining([
        { value: 18, unit: 'm²' },
        { value: 29, unit: 'dB' },
        { value: 4, unit: 'người' },
      ])
    );
  });

  test('dung tích tủ lạnh dạng lít', () => {
    expect(extractSpecMentions('Dung tích 313 lít, đủ dùng cho gia đình đông người')).toEqual([
      { value: 313, unit: 'lít' },
    ]);
  });

  test('không có thông số -> mảng rỗng', () => {
    expect(extractSpecMentions('Thiết kế đẹp, màu sắc hiện đại')).toEqual([]);
  });
});
