'use strict';

const { buildKnownFacts } = require('../src/validation/knownFacts');

function rankedItem({ id, price, area, noise }) {
  return {
    product_id: id,
    effective_price: price,
    source: {
      room_area_range: area || null,
      noise_db: noise || null,
    },
  };
}

describe('buildKnownFacts', () => {
  test('thu thập giá, ngân sách khách và range thông số từ Top N', () => {
    const rankingResult = {
      results: [
        rankedItem({ id: 'A', price: 12_000_000, area: { min: 15, max: 20 }, noise: { min: 29, max: 45 } }),
        rankedItem({ id: 'B', price: 18_000_000, area: { min: 20, max: 30 } }),
      ],
    };
    const state = { slots: { budget_max: 20_000_000, room_area_m2: 18 } };

    const facts = buildKnownFacts(rankingResult, state);

    expect(facts.money).toEqual(expect.arrayContaining([12_000_000, 18_000_000, 20_000_000]));
    expect(facts.spec['m²']).toEqual(expect.arrayContaining([15, 20, 30, 18]));
    expect(facts.spec.dB).toEqual(expect.arrayContaining([29, 45]));
  });

  test('thêm hiệu số giữa các mức giá để câu so sánh "rẻ hơn X triệu" không bị chặn nhầm', () => {
    const rankingResult = {
      results: [rankedItem({ id: 'A', price: 12_000_000 }), rankedItem({ id: 'B', price: 15_000_000 })],
    };
    const facts = buildKnownFacts(rankingResult, {});
    expect(facts.money).toContain(3_000_000);
  });

  test('không có state/slots vẫn hoạt động bình thường', () => {
    const facts = buildKnownFacts({ results: [] }, undefined);
    expect(facts.money).toEqual([]);
    expect(facts.spec['m²']).toEqual([]);
  });
});
