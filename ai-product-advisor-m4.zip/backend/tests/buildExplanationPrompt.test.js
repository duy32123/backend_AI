'use strict';

const { buildExplanationPrompt } = require('../src/explanation/buildExplanationPrompt');

const rankingResult = {
  relaxed_steps: ['dropped_room_area_constraint'],
  results: [
    {
      product_id: 'AC-1',
      model_code: 'AC-1',
      effective_price: 12_000_000,
      total_score: 88,
      matched_reasons: ['Phù hợp ngân sách.'],
      tradeoffs: [],
      missing_data: [],
      source: {
        category: 'may_lanh',
        brand: 'Samsung',
        room_area_range: { min: 15, max: 20 },
        noise_db: { min: 29, max: 45 },
        energy_label: '5 sao',
        power_saving_tech: 'Inverter',
        loai_may: '1 chiều',
      },
    },
  ],
};

describe('buildExplanationPrompt', () => {
  test('user payload chỉ chứa đúng sản phẩm trong Top N, không rò rỉ dữ liệu ngoài', () => {
    const state = { slots: { budget_max: 20_000_000, room_area_m2: 18 } };
    const { user } = buildExplanationPrompt(rankingResult, state);
    const payload = JSON.parse(user);

    expect(payload.products).toHaveLength(1);
    expect(payload.products[0].product_id).toBe('AC-1');
    expect(payload.products[0].effective_price).toBe(12_000_000);
    expect(payload.products[0].key_specs.room_area_range).toEqual({ min: 15, max: 20 });
    expect(payload.customer_needs.budget_max).toBe(20_000_000);
    expect(payload.relaxed_constraints).toEqual(['dropped_room_area_constraint']);
  });

  test('system prompt cấm bịa sản phẩm/số liệu và ép output JSON thuần', () => {
    const { system } = buildExplanationPrompt(rankingResult, {});
    expect(system).toMatch(/KHÔNG được bịa thêm sản phẩm/);
    expect(system).toMatch(/KHÔNG được suy diễn/);
    expect(system).toMatch(/CHỈ là JSON thuần/);
  });
});
