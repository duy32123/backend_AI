'use strict';

describe('llmClient', () => {
  const ORIGINAL_ENV = { ...process.env };

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
    jest.resetModules();
  });

  test('getApiKey() đọc từ LLM_API_KEY hoặc ANTHROPIC_API_KEY', () => {
    jest.resetModules();
    process.env.LLM_API_KEY = 'sk-test-123';
    delete process.env.ANTHROPIC_API_KEY;
    const { getApiKey } = require('../src/llm/llmClient');
    expect(getApiKey()).toBe('sk-test-123');
  });

  test('callLLM() throw lỗi rõ ràng khi chưa cấu hình API key, KHÔNG gọi mạng', async () => {
    jest.resetModules();
    delete process.env.LLM_API_KEY;
    delete process.env.ANTHROPIC_API_KEY;
    const { callLLM } = require('../src/llm/llmClient');

    await expect(callLLM({ system: 's', user: 'u' })).rejects.toThrow(/API key/i);
  });
});
