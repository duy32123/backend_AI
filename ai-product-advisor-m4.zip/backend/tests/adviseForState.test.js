'use strict';

const { createConversationState } = require('../src/state/conversationState');
const { processTurn } = require('../src/turn');
const { adviseForState } = require('../src/adviseForState');
const { clearCatalogCache } = require('../src/data/catalogStore');

function fakeLlmClientEchoingRealPrices() {
  // Fake LLM "trung thực": chỉ dùng đúng số liệu có trong prompt (mô phỏng
  // một LLM tuân thủ tốt), để test luồng thành công end-to-end.
  return async ({ user }) => {
    const payload = JSON.parse(user);
    const items = payload.products.map((p) => ({
      product_id: p.product_id,
      headline: `Giá ${Math.round(p.effective_price / 1_000_000)} triệu.`,
      pros: ['Phù hợp nhu cầu đã nêu.'],
      cons: [],
      recommendation_reason: 'Khớp với ngân sách và diện tích khách yêu cầu.',
    }));
    return { text: JSON.stringify({ summary: 'Gợi ý phù hợp nhất theo nhu cầu.', items }) };
  };
}

function fakeLlmClientHallucinating() {
  // Fake LLM "không trung thực": bịa giá + bịa thêm 1 sản phẩm ngoài Top N.
  return async () => ({
    text: JSON.stringify({
      summary: 'Tóm tắt.',
      items: [
        { product_id: 'SAN-PHAM-BIA-RA', headline: 'Giá chỉ 1 triệu, siêu hời!', pros: [], cons: [], recommendation_reason: 'x' },
      ],
    }),
  });
}

describe('adviseForState — pipeline đầy đủ 4 module trên catalog thật', () => {
  afterEach(() => clearCatalogCache());

  test('kịch bản thành công: LLM trung thực -> status ok, giá hiển thị khớp record gốc', async () => {
    let state = createConversationState('sess_1');
    const turn = processTurn(state, {
      category: 'máy lạnh',
      budget: '20 triệu',
      area: '18m2',
      location: 'phòng ngủ',
    });
    state = turn.state;
    expect(turn.status).toBe('ready');

    const result = await adviseForState(state, { llmClient: fakeLlmClientEchoingRealPrices(), topN: 3 });

    expect(['ok', 'relaxed']).toContain(result.retrieval.status);
    expect(result.status === 'ok' || result.status === 'corrected').toBe(true);
    expect(result.items.length).toBeGreaterThan(0);

    result.items.forEach((item) => {
      const rankedSource = result.ranking.results.find((r) => r.product_id === item.product_id);
      expect(item.effective_price).toBe(rankedSource.effective_price);
    });
  });

  test('kịch bản LLM bịa sản phẩm ngoài Top N + bịa giá -> guardrail chặn hết, status blocked', async () => {
    let state = createConversationState('sess_2');
    const turn = processTurn(state, {
      category: 'máy lạnh',
      budget: '20 triệu',
      area: '18m2',
      location: 'phòng ngủ',
    });
    state = turn.state;

    const result = await adviseForState(state, { llmClient: fakeLlmClientHallucinating(), topN: 3 });

    expect(result.rejected_items.some((r) => r.product_id === 'SAN-PHAM-BIA-RA')).toBe(true);
    // Sản phẩm thật trong Top N vẫn được trả về (không có lời giải thích LLM) thay vì mất trắng
    expect(result.items.length).toBeGreaterThan(0);
    result.items.forEach((item) => expect(item.llm_explanation_missing).toBe(true));
    expect(result.status).toBe('blocked');
  });

  test('ngân sách phi thực tế -> retrieval no_results, KHÔNG gọi LLM', async () => {
    const llmClient = jest.fn();
    let state = createConversationState('sess_3');
    const turn = processTurn(state, {
      category: 'máy lạnh',
      budget: '20 triệu',
      area: '18m2',
      location: 'phòng ngủ',
    });
    state = { ...turn.state, slots: { ...turn.state.slots, budget_max: 100_000 } };

    const result = await adviseForState(state, { llmClient });
    expect(result.status).toBe('no_results');
    expect(llmClient).not.toHaveBeenCalled();
  });
});
