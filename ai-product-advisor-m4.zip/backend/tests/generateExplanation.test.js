'use strict';

const { generateExplanation } = require('../src/explanation/generateExplanation');

const rankingResultOk = {
  status: 'ok',
  relaxed_steps: [],
  results: [
    {
      product_id: 'AC-1',
      model_code: 'AC-1',
      effective_price: 12_000_000,
      matched_reasons: [],
      tradeoffs: [],
      missing_data: [],
      source: { category: 'may_lanh', room_area_range: { min: 15, max: 20 } },
    },
  ],
};

function fakeLlmClient(responseText) {
  return async () => ({ text: responseText });
}

describe('generateExplanation', () => {
  test('không gọi LLM khi ranking chưa sẵn sàng (not_ready)', async () => {
    const llmClient = jest.fn();
    const result = await generateExplanation({ status: 'not_ready', missing_slots: ['budget_max'] }, {}, { llmClient });
    expect(result.status).toBe('not_ready');
    expect(llmClient).not.toHaveBeenCalled();
  });

  test('không gọi LLM khi ranking không có kết quả (no_results)', async () => {
    const llmClient = jest.fn();
    const result = await generateExplanation({ status: 'no_results', message: 'Chưa có dữ liệu.' }, {}, { llmClient });
    expect(result.status).toBe('no_results');
    expect(llmClient).not.toHaveBeenCalled();
  });

  test('parse JSON hợp lệ từ LLM (kể cả khi bọc trong ```json) và chạy qua guardrail', async () => {
    const llmJson = JSON.stringify({
      summary: 'Tóm tắt.',
      items: [{ product_id: 'AC-1', headline: 'Phù hợp ngân sách.', pros: [], cons: [], recommendation_reason: 'OK' }],
    });
    const wrapped = '```json\n' + llmJson + '\n```';

    const result = await generateExplanation(rankingResultOk, {}, { llmClient: fakeLlmClient(wrapped) });
    expect(result.status).toBe('ok');
    expect(result.items[0].product_id).toBe('AC-1');
  });

  test('LLM trả text không phải JSON hợp lệ -> status llm_parse_error, không crash', async () => {
    const result = await generateExplanation(rankingResultOk, {}, { llmClient: fakeLlmClient('không phải JSON đâu') });
    expect(result.status).toBe('llm_parse_error');
    expect(result.error).toBeTruthy();
  });

  test('llmClient throw lỗi (vd lỗi mạng/API key sai) -> status llm_error, không crash pipeline', async () => {
    const throwingClient = async () => {
      throw new Error('401 Unauthorized');
    };
    const result = await generateExplanation(rankingResultOk, {}, { llmClient: throwingClient });
    expect(result.status).toBe('llm_error');
    expect(result.error).toMatch(/401/);
  });
});
