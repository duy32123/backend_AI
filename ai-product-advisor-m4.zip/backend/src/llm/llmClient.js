'use strict';

const { loadEnvFile } = require('../config/env');

loadEnvFile(); // nạp backend/.env nếu có — không ghi đè biến môi trường đã set sẵn

const DEFAULT_MODEL = process.env.LLM_MODEL || process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6';
const DEFAULT_BASE_URL = process.env.LLM_BASE_URL || process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com/v1/messages';
const DEFAULT_API_VERSION = process.env.LLM_API_VERSION || '2023-06-01';

/**
 * getApiKey() — đọc API key từ biến môi trường. Ưu tiên LLM_API_KEY (tên
 * trung lập, không gắn cứng vào 1 nhà cung cấp), fallback ANTHROPIC_API_KEY.
 *
 * KHÔNG hardcode key ở bất kỳ đâu trong code — người dùng tự điền vào
 * backend/.env (xem backend/.env.example) hoặc export biến môi trường
 * trước khi chạy.
 */
function getApiKey() {
  return process.env.LLM_API_KEY || process.env.ANTHROPIC_API_KEY || null;
}

/**
 * callLLM({ system, user, maxTokens, model, apiKey, baseUrl }) -> { text, raw }
 *
 * Gọi thẳng Anthropic Messages API (tương thích với model Claude do người
 * dùng tự cấu hình qua LLM_MODEL/ANTHROPIC_MODEL). Nếu người dùng dùng nhà
 * cung cấp khác có API tương thích /v1/messages, chỉ cần đổi LLM_BASE_URL.
 *
 * Đây là điểm gọi LLM DUY NHẤT cho Module 3 (giải thích) — không được dùng
 * ở Module 1/2 (những module đó chỉ dùng code thuần, xem docs/technical-spec.md).
 */
async function callLLM({ system, user, maxTokens = 1024, model, apiKey, baseUrl } = {}) {
  const key = apiKey || getApiKey();
  if (!key) {
    throw new Error(
      'Thiếu API key cho LLM. Hãy điền vào backend/.env (copy từ backend/.env.example), ' +
        'biến LLM_API_KEY hoặc ANTHROPIC_API_KEY, trước khi gọi generateExplanation với client thật. ' +
        'Khi test, hãy truyền options.llmClient giả lập thay vì gọi API thật.'
    );
  }

  const url = baseUrl || DEFAULT_BASE_URL;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': key,
      'anthropic-version': DEFAULT_API_VERSION,
    },
    body: JSON.stringify({
      model: model || DEFAULT_MODEL,
      max_tokens: maxTokens,
      system,
      messages: [{ role: 'user', content: user }],
    }),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    throw new Error(`LLM API trả lỗi ${response.status}: ${errText}`);
  }

  const data = await response.json();
  const text = (data.content || [])
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('\n');

  return { text, raw: data };
}

module.exports = { callLLM, getApiKey, DEFAULT_MODEL, DEFAULT_BASE_URL };
