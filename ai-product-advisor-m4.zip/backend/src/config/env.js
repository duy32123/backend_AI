'use strict';

const fs = require('fs');
const path = require('path');

/**
 * loadEnvFile(customPath?) — nạp file .env (KEY=VALUE mỗi dòng) vào
 * process.env, KHÔNG ghi đè biến môi trường đã được set từ bên ngoài
 * (vd export trực tiếp trong shell/CI). Không phụ thuộc package ngoài
 * (dotenv) — chỉ đọc/parse thủ công, tối giản.
 *
 * Thứ tự tìm file: customPath -> ./.env (cwd) -> backend/.env (cạnh package.json).
 * Chỉ nạp file ĐẦU TIÊN tìm thấy.
 */
function loadEnvFile(customPath) {
  const candidates = [customPath, path.join(process.cwd(), '.env'), path.join(__dirname, '..', '..', '.env')].filter(
    Boolean
  );

  const envPath = candidates.find((p) => fs.existsSync(p));
  if (!envPath) return { loaded: false, path: null };

  const content = fs.readFileSync(envPath, 'utf8');
  content.split('\n').forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) return;

    const idx = trimmed.indexOf('=');
    if (idx === -1) return;

    const key = trimmed.slice(0, idx).trim();
    let value = trimmed.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }

    if (process.env[key] === undefined) {
      process.env[key] = value;
    }
  });

  return { loaded: true, path: envPath };
}

module.exports = { loadEnvFile };
