'use strict';

const { retrieveForState } = require('./retrieveForState');
const { rankProducts } = require('./ranking/rankProducts');
const { generateExplanation } = require('./explanation/generateExplanation');

/**
 * adviseForState(state, options) -> kết quả cuối cùng sẵn sàng trả cho
 * frontend, đã đi qua đủ 4 module (Slot-filling đã xong ở turn.js trước đó
 * -> Retrieval/Filter -> Ranking -> Explanation + Validation/Guardrail).
 *
 * options:
 *   - catalogOverride: catalog giả lập cho test (bỏ qua đọc Excel thật)
 *   - llmClient: hàm async ({system,user,maxTokens}) -> {text}, mặc định
 *     gọi API thật qua src/llm/llmClient.js (cần LLM_API_KEY trong .env)
 *   - topN: số sản phẩm xếp hạng tối đa (mặc định 3)
 *   - maxTokens: giới hạn token cho lời gọi LLM giải thích
 */
async function adviseForState(state, options = {}) {
  const retrieval = retrieveForState(state, options.catalogOverride || null);
  const ranking = rankProducts(retrieval, state, { topN: options.topN });

  if (ranking.status === 'not_ready' || ranking.status === 'no_results') {
    return { ...ranking, state, retrieval, ranking };
  }

  const explanation = await generateExplanation(ranking, state, {
    llmClient: options.llmClient,
    maxTokens: options.maxTokens,
  });

  return { ...explanation, state, retrieval, ranking };
}

module.exports = { adviseForState };
