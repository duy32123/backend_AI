'use strict';

/**
 * extractClaims.js — trích các "claim số" trong văn bản do LLM sinh ra để
 * đối chiếu lại với dữ liệu thật (Module 4 — Validation/Guardrail).
 *
 * Tách riêng 2 nhóm vì đơn vị & cách parse khác nhau:
 *  - Tiền VND: "20 triệu", "14.990.000đ", "18,500,000 vnd"
 *  - Thông số kỹ thuật có đơn vị: "18m²", "29 dB", "313 lít", "4 người"
 */

function toNumber(raw) {
  return parseFloat(raw.replace(',', '.'));
}

/**
 * extractMoneyMentions("Giá khoảng 20 triệu, rẻ hơn 3 triệu so với model kia")
 * -> [20000000, 3000000]
 */
function extractMoneyMentions(text) {
  if (typeof text !== 'string' || !text) return [];
  const results = [];

  // "20 triệu" / "3,5 triệu" / "20tr"
  const millionRegex = /(\d+(?:[.,]\d+)?)\s*(triệu|trieu|tr)\b/gi;
  let m;
  while ((m = millionRegex.exec(text)) !== null) {
    results.push(Math.round(toNumber(m[1]) * 1_000_000));
  }

  // "14.990.000đ" / "14,990,000 vnd" / "18.500.000₫" — số có dấu phân cách hàng nghìn, >= 2 nhóm 3 chữ số
  const bigNumberRegex = /(\d{1,3}(?:[.,]\d{3}){2,})\s*(đ|vnđ|vnd|₫)?/gi;
  while ((m = bigNumberRegex.exec(text)) !== null) {
    const digits = m[1].replace(/[.,]/g, '');
    results.push(parseInt(digits, 10));
  }

  return results;
}

const SPEC_UNIT_PATTERNS = [
  { unit: 'm²', regex: /(\d+(?:[.,]\d+)?)\s*(m²|m2)(?![a-zA-Z0-9])/gi },
  { unit: 'dB', regex: /(\d+(?:[.,]\d+)?)\s*(dB|db)(?![a-zA-Z0-9])/gi },
  { unit: 'lít', regex: /(\d+(?:[.,]\d+)?)\s*(lít|lit)(?![a-zA-Z0-9])/gi },
  { unit: 'người', regex: /(\d+(?:[.,]\d+)?)\s*người(?![a-zA-Z0-9])/gi },
];

/**
 * extractSpecMentions("Phòng 18m², chạy êm chỉ 29 dB")
 * -> [{ value: 18, unit: 'm²' }, { value: 29, unit: 'dB' }]
 */
function extractSpecMentions(text) {
  if (typeof text !== 'string' || !text) return [];
  const results = [];

  for (const { unit, regex } of SPEC_UNIT_PATTERNS) {
    let m;
    const re = new RegExp(regex.source, regex.flags);
    while ((m = re.exec(text)) !== null) {
      results.push({ value: toNumber(m[1]), unit });
    }
  }

  return results;
}

module.exports = { extractMoneyMentions, extractSpecMentions };
