'use strict';

const { extractMoneyMentions, extractSpecMentions } = require('./extractClaims');
const { buildKnownFacts } = require('./knownFacts');

const MONEY_TOLERANCE = 0.03; // 3% — cho phép LLM làm tròn nhẹ ("gần 15 triệu" cho 14.990.000)
const SPEC_TOLERANCE = 0.02; // 2% — thông số kỹ thuật nên khớp gần như tuyệt đối

const FALLBACK_TEXT =
  'Thông tin này chưa khớp với dữ liệu catalog nên đã được ẩn để tránh sai lệch — vui lòng xem thông số gốc bên dưới.';

function isKnownValue(value, knownList, tolerance) {
  return knownList.some((k) => {
    const denom = Math.max(Math.abs(k), 1);
    return Math.abs(value - k) / denom <= tolerance;
  });
}

function checkTextField(text, facts) {
  if (typeof text !== 'string' || !text.trim()) {
    return { ok: true, unverified: [] };
  }

  const money = extractMoneyMentions(text);
  const specs = extractSpecMentions(text);

  const badMoney = money.filter((v) => !isKnownValue(v, facts.money, MONEY_TOLERANCE));
  const badSpecs = specs.filter((s) => !isKnownValue(s.value, facts.spec[s.unit] || [], SPEC_TOLERANCE));

  if (badMoney.length === 0 && badSpecs.length === 0) {
    return { ok: true, unverified: [] };
  }

  return {
    ok: false,
    unverified: [
      ...badMoney.map((v) => ({ type: 'money', value: v })),
      ...badSpecs.map((s) => ({ type: 'spec', value: s.value, unit: s.unit })),
    ],
  };
}

function validateAndMaybeReplace(text, facts, productId, fieldPath, corrections) {
  const check = checkTextField(text, facts);
  if (check.ok) return typeof text === 'string' ? text : '';

  corrections.push({
    product_id: productId,
    field: fieldPath,
    original_text: text,
    reason: 'unverified_numeric_claim',
    unverified_values: check.unverified,
  });
  return FALLBACK_TEXT;
}

/**
 * validateExplanation(llmOutput, rankingResult, state) -> {
 *   status: 'ok' | 'corrected' | 'blocked',
 *   summary: string,
 *   items: ValidatedItem[],
 *   corrections: Correction[],
 *   rejected_items: RejectedItem[],
 *   message: string | null
 * }
 *
 * Đây là guardrail bắt buộc trước khi trả lời khách hàng (Module 4):
 *  1. product_id không nằm trong Top N đã lọc/rank -> LOẠI HẲN item đó
 *     (không được để lọt sản phẩm LLM tự bịa ra).
 *  2. Giá hiển thị (`effective_price`) LUÔN lấy từ record gốc đã rank,
 *     KHÔNG BAO GIỜ lấy theo số LLM tự viết ra trong text.
 *  3. Mọi câu text (headline/pros/cons/recommendation_reason) chứa số tiền
 *     hoặc thông số không khớp dữ liệu thật (ngoài dung sai cho phép) đều
 *     bị thay bằng thông báo an toàn, đồng thời ghi log vào `corrections`
 *     để có thể audit / cải thiện prompt sau này.
 *  4. Nếu sau kiểm tra không còn item hợp lệ nào -> status "blocked",
 *     KHÔNG trả nội dung LLM sinh ra cho khách (tránh trả lời rỗng/sai).
 */
function validateExplanation(llmOutput, rankingResult, state) {
  const topNResults = (rankingResult && rankingResult.results) || [];
  const productById = new Map(topNResults.map((r) => [String(r.product_id), r]));

  const corrections = [];
  const rejectedItems = [];
  const items = [];

  const rawItems = Array.isArray(llmOutput && llmOutput.items) ? llmOutput.items : [];
  const facts = buildKnownFacts(rankingResult, state);

  for (const rawItem of rawItems) {
    const pid = rawItem && rawItem.product_id != null ? String(rawItem.product_id) : null;

    if (!pid || !productById.has(pid)) {
      rejectedItems.push({ product_id: pid, reason: 'unknown_product_id', raw: rawItem });
      continue;
    }

    const ranked = productById.get(pid);
    const pros = Array.isArray(rawItem.pros) ? rawItem.pros : [];
    const cons = Array.isArray(rawItem.cons) ? rawItem.cons : [];

    items.push({
      product_id: pid,
      model_code: ranked.model_code,
      effective_price: ranked.effective_price, // luôn lấy từ nguồn thật
      headline: validateAndMaybeReplace(rawItem.headline, facts, pid, 'headline', corrections),
      pros: pros.map((t, idx) => validateAndMaybeReplace(t, facts, pid, `pros[${idx}]`, corrections)),
      cons: cons.map((t, idx) => validateAndMaybeReplace(t, facts, pid, `cons[${idx}]`, corrections)),
      recommendation_reason: validateAndMaybeReplace(
        rawItem.recommendation_reason,
        facts,
        pid,
        'recommendation_reason',
        corrections
      ),
      matched_reasons: ranked.matched_reasons,
      tradeoffs: ranked.tradeoffs,
      missing_data: ranked.missing_data,
      data_source: { product_id: ranked.product_id, model_code: ranked.model_code },
    });
  }

  // Sản phẩm nằm trong Top N nhưng LLM bỏ sót hoàn toàn -> vẫn đưa vào kết
  // quả với dữ liệu thô từ ranking (không có lời giải thích của LLM), để
  // khách không mất sản phẩm đã được xếp hạng hợp lệ chỉ vì LLM quên nhắc.
  const explainedIds = new Set(items.map((i) => i.product_id));
  for (const ranked of topNResults) {
    if (explainedIds.has(String(ranked.product_id))) continue;
    items.push({
      product_id: String(ranked.product_id),
      model_code: ranked.model_code,
      effective_price: ranked.effective_price,
      headline: null,
      pros: [],
      cons: [],
      recommendation_reason: null,
      matched_reasons: ranked.matched_reasons,
      tradeoffs: ranked.tradeoffs,
      missing_data: ranked.missing_data,
      data_source: { product_id: ranked.product_id, model_code: ranked.model_code },
      llm_explanation_missing: true,
    });
  }

  items.sort((a, b) => {
    const ra = topNResults.findIndex((r) => String(r.product_id) === a.product_id);
    const rb = topNResults.findIndex((r) => String(r.product_id) === b.product_id);
    return ra - rb;
  });

  const status = items.every((i) => i.llm_explanation_missing)
    ? 'blocked'
    : corrections.length > 0 || rejectedItems.length > 0
      ? 'corrected'
      : 'ok';

  return {
    status,
    summary: typeof (llmOutput && llmOutput.summary) === 'string' ? llmOutput.summary : '',
    items,
    corrections,
    rejected_items: rejectedItems,
    message: status === 'blocked' ? 'Không có nội dung giải thích hợp lệ từ LLM sau khi kiểm tra guardrail.' : null,
  };
}

module.exports = { validateExplanation, checkTextField, FALLBACK_TEXT, MONEY_TOLERANCE, SPEC_TOLERANCE };
