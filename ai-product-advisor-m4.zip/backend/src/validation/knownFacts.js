'use strict';

/**
 * buildKnownFacts(rankingResult, state) -> {
 *   money: number[],          // mọi số tiền hợp lệ có thể xuất hiện trong lời giải thích
 *   spec: { 'm²': number[], 'dB': number[], 'lít': number[], 'người': number[] }
 * }
 *
 * Tập "sự thật" này là nguồn duy nhất được dùng để xác minh claim số của
 * LLM (Module 4). Bất kỳ số nào LLM nhắc tới mà KHÔNG khớp (trong dung sai)
 * với tập này đều bị coi là chưa xác minh được — xem validateExplanation.js.
 *
 * Bao gồm cả các số hợp lý mà LLM có thể tạo ra một cách hợp lệ khi so
 * sánh (vd "rẻ hơn X triệu" — X là hiệu giữa 2 giá thật trong Top N) để
 * tránh false-positive khi guardrail chặn nhầm câu so sánh đúng.
 */
function buildKnownFacts(rankingResult, state) {
  const money = new Set();
  const spec = { 'm²': new Set(), dB: new Set(), lít: new Set(), người: new Set() };

  const slots = (state && state.slots) || state || {};
  if (typeof slots.budget_max === 'number') money.add(slots.budget_max);
  if (typeof slots.budget_min === 'number') money.add(slots.budget_min);
  if (typeof slots.room_area_m2 === 'number') spec['m²'].add(slots.room_area_m2);
  if (typeof slots.household_size === 'number') spec['người'].add(slots.household_size);

  const prices = [];
  const results = (rankingResult && rankingResult.results) || [];

  for (const item of results) {
    if (typeof item.effective_price === 'number') {
      money.add(item.effective_price);
      prices.push(item.effective_price);
    }

    const src = item.source || {};
    if (src.room_area_range) {
      spec['m²'].add(src.room_area_range.min);
      if (src.room_area_range.max != null) spec['m²'].add(src.room_area_range.max);
    }
    if (src.noise_db) {
      spec.dB.add(src.noise_db.min);
      spec.dB.add(src.noise_db.max);
    }
    if (typeof src.capacity_total_liters === 'number') spec['lít'].add(src.capacity_total_liters);
    if (src.household_range) {
      spec['người'].add(src.household_range.min);
      if (src.household_range.max != null) spec['người'].add(src.household_range.max);
    }
  }

  // Hiệu giữa các mức giá — cho phép câu so sánh "rẻ hơn X triệu" hợp lệ
  for (let i = 0; i < prices.length; i += 1) {
    for (let j = i + 1; j < prices.length; j += 1) {
      money.add(Math.abs(prices[i] - prices[j]));
    }
  }

  return {
    money: [...money],
    spec: Object.fromEntries(Object.entries(spec).map(([unit, set]) => [unit, [...set]])),
  };
}

module.exports = { buildKnownFacts };
