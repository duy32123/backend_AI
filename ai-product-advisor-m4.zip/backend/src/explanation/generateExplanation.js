'use strict';

const { buildExplanationPrompt } = require('./buildExplanationPrompt');
const { validateExplanation } = require('../validation/validateExplanation');
const { callLLM } = require('../llm/llmClient');

/**
 * parseJsonFromLlmText(text) — LLM đôi khi vẫn bọc JSON trong ```json ... ```
 * dù đã dặn "chỉ trả JSON thuần". Bóc markdown fence nếu có rồi parse.
 */
function parseJsonFromLlmText(text) {
  if (typeof text !== 'string') {
    throw new Error('LLM không trả về text hợp lệ.');
  }
  const stripped = text
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```\s*$/i, '')
    .trim();

  try {
    return JSON.parse(stripped);
  } catch (err) {
    throw new Error(`Không parse được JSON từ output LLM: ${err.message}`);
  }
}

/**
 * generateExplanation(rankingResult, state, options) -> {
 *   status, summary, items, corrections, rejected_items, message, ranking
 * }
 *
 * options.llmClient: hàm async ({system, user, maxTokens}) -> {text} — mặc
 * định dùng src/llm/llmClient.js (gọi API thật, cần LLM_API_KEY/ANTHROPIC_API_KEY).
 * Trong test/CI, LUÔN truyền llmClient giả lập để không phụ thuộc mạng/API key.
 *
 * Không gọi LLM nếu ranking chưa sẵn sàng hoặc không có sản phẩm — tránh
 * tốn API call vô ích và tránh LLM tự "chữa cháy" khi không có dữ liệu.
 */
async function generateExplanation(rankingResult, state, options = {}) {
  if (!rankingResult || rankingResult.status === 'not_ready') {
    return {
      status: 'not_ready',
      missing_slots: (rankingResult && rankingResult.missing_slots) || [],
      items: [],
      ranking: rankingResult || null,
    };
  }

  if (rankingResult.status === 'no_results' || !Array.isArray(rankingResult.results) || rankingResult.results.length === 0) {
    return {
      status: 'no_results',
      message: rankingResult.message || 'Không có sản phẩm để giải thích.',
      items: [],
      ranking: rankingResult,
    };
  }

  const { system, user } = buildExplanationPrompt(rankingResult, state);
  const llmClient = options.llmClient || callLLM;

  let llmResponse;
  try {
    llmResponse = await llmClient({ system, user, maxTokens: options.maxTokens || 1500 });
  } catch (err) {
    return {
      status: 'llm_error',
      error: err.message,
      items: [],
      ranking: rankingResult,
    };
  }

  let parsed;
  try {
    parsed = parseJsonFromLlmText(llmResponse.text);
  } catch (err) {
    return {
      status: 'llm_parse_error',
      error: err.message,
      raw_text: llmResponse.text,
      items: [],
      ranking: rankingResult,
    };
  }

  const validation = validateExplanation(parsed, rankingResult, state);
  return { ...validation, ranking: rankingResult };
}

module.exports = { generateExplanation, parseJsonFromLlmText };
