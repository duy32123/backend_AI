'use strict';

/**
 * toLlmProductPayload(rankedItem) — trích đúng field cần thiết từ 1 kết
 * quả đã rank để đưa vào prompt. Không đưa nguyên `_raw`/`source` đầy đủ
 * (tránh prompt quá dài và tránh lộ field nội bộ không liên quan), nhưng
 * mọi số liệu đưa vào đều lấy trực tiếp từ record đã lọc/rank — không có
 * số liệu nào do bước này tự sinh ra.
 */
function toLlmProductPayload(rankedItem) {
  const src = rankedItem.source || {};
  const category = src.category;

  const keySpecs =
    category === 'tu_lanh'
      ? {
          household_range: src.household_range,
          capacity_total_liters: src.capacity_total_liters,
          door_count: src.door_count,
          kieu_dang: src.kieu_dang,
          power_saving_tech: src.power_saving_tech,
        }
      : {
          room_area_range: src.room_area_range,
          noise_db: src.noise_db,
          energy_label: src.energy_label,
          power_saving_tech: src.power_saving_tech,
          loai_may: src.loai_may,
        };

  return {
    product_id: rankedItem.product_id,
    model_code: rankedItem.model_code,
    brand: src.brand || null,
    effective_price: rankedItem.effective_price,
    total_score: rankedItem.total_score,
    key_specs: keySpecs,
    matched_reasons: rankedItem.matched_reasons,
    tradeoffs: rankedItem.tradeoffs,
    missing_data: rankedItem.missing_data,
  };
}

const OUTPUT_SCHEMA_EXAMPLE = {
  summary: 'Một câu tóm tắt ngắn gọn giúp khách chọn nhanh giữa các lựa chọn.',
  items: [
    {
      product_id: 'model_code của sản phẩm, PHẢI trùng khớp với product_id trong dữ liệu products được cung cấp',
      headline: 'Một câu ngắn nêu điểm nổi bật nhất, ngôn ngữ dễ hiểu, không thuật ngữ marketing',
      pros: ['Ưu điểm 1 (ngắn gọn)', 'Ưu điểm 2 (ngắn gọn)'],
      cons: ['Nhược điểm/trade-off nếu có, tối đa 2'],
      recommendation_reason: 'Vì sao nên/không nên chọn sản phẩm này so với các lựa chọn khác trong danh sách',
    },
  ],
};

/**
 * buildExplanationPrompt(rankingResult, state) -> { system, user }
 *
 * Nguyên tắc bắt buộc (Module 3 → nối vào Module 4 guardrail):
 *  - CHỈ được dùng dữ liệu trong `products` — không thêm sản phẩm ngoài
 *    danh sách, không suy diễn thông số/giá/khuyến mãi ngoài dữ liệu.
 *  - Nếu field nào trong products là null/thiếu, PHẢI nói rõ "chưa có dữ
 *    liệu" thay vì đoán.
 *  - Output CHỈ là JSON theo đúng schema — không thêm chữ ngoài JSON, để
 *    Module 4 (validation/guardrail) parse và đối chiếu lại từng số liệu
 *    trước khi trả cho khách.
 */
function buildExplanationPrompt(rankingResult, state) {
  const slots = state?.slots || state || {};
  const products = rankingResult.results.map(toLlmProductPayload);

  const system = [
    'Bạn là trợ lý tư vấn sản phẩm điện máy, nhiệm vụ DUY NHẤT là diễn giải và so sánh',
    'CÁC SẢN PHẨM ĐƯỢC CUNG CẤP SẴN trong "products" bên dưới bằng ngôn ngữ dễ hiểu cho',
    'khách hàng phổ thông (không dùng thuật ngữ marketing, không phóng đại).',
    '',
    'QUY TẮC BẮT BUỘC (VI PHẠM SẼ BỊ CHẶN Ở BƯỚC KIỂM TRA SAU):',
    '1. CHỈ được nhắc tới đúng các sản phẩm có trong "products". KHÔNG được bịa thêm sản phẩm khác.',
    '2. CHỈ được dùng số liệu (giá, thông số) CÓ TRONG "products". KHÔNG được suy diễn, làm tròn tuỳ ý,',
    '   hoặc tự nghĩ ra số liệu không có trong dữ liệu.',
    '3. Nếu một field trong key_specs là null, hãy nói "chưa có dữ liệu" thay vì đoán giá trị.',
    '4. Mỗi sản phẩm cần: 1 headline, 2-3 pros, tối đa 2 cons (nếu có trade-off thật sự, lấy gợi ý',
    '   từ trường "tradeoffs" đã cho sẵn), và recommendation_reason so với các lựa chọn khác.',
    '5. product_id trong output PHẢI khớp CHÍNH XÁC với product_id trong dữ liệu products.',
    '6. Output CHỈ là JSON thuần theo đúng schema bên dưới — không markdown, không giải thích thêm.',
    '',
    `Schema output mẫu: ${JSON.stringify(OUTPUT_SCHEMA_EXAMPLE, null, 2)}`,
  ].join('\n');

  const user = JSON.stringify(
    {
      customer_needs: slots,
      relaxed_constraints: rankingResult.relaxed_steps || [],
      products,
    },
    null,
    2
  );

  return { system, user };
}

module.exports = { buildExplanationPrompt, toLlmProductPayload };
