# AI Product Comparison Advisor — Backend

Trợ lý AI so sánh và tư vấn sản phẩm theo nhu cầu thật của khách hàng.
Vietnam Innovation Challenge 2026 — đối tác Điện Máy Xanh.

## Cấu trúc thư mục

```
docs/
  technical-spec.md        # Kiến trúc, user flow, API contract, schema, kế hoạch milestone
backend/
  .env.example              # Mẫu cấu hình API key LLM — copy thành .env rồi tự điền key
  data/
    Spec_cate_gia.xlsx      # Catalog gốc (Máy lạnh, Tủ lạnh...)
  src/
    schema/                 # Slot schema theo category (M1)
    nlu/                     # Canonical NLU + prompt builder cho LLM trích slot (M1)
    state/                   # Conversation state, merge, missing slots, chống hỏi lặp (M1)
    turn.js                  # Orchestrator Module 1 (một lượt hội thoại slot-filling)
    data/                     # Load & parse catalog thật từ Excel (M2)
    retrieval/                # Filter sản phẩm bằng code + xử lý 0 kết quả (M2)
    retrieveForState.js       # Nối Module 1 (state đủ slot) với Module 2 (retrieval)
    ranking/                   # Rule-based scoring, chọn Top N (M3)
    recommendForState.js       # Nối Module 2 với Module 3 (retrieval → ranking)
    explanation/                 # Prompt builder + orchestrator gọi LLM giải thích Top N (M4)
    validation/                  # Guardrail: đối chiếu claim của LLM với record gốc (M4)
    llm/llmClient.js             # Client gọi LLM thật (API key đọc từ .env, không hardcode)
    config/env.js                 # Loader .env tối giản, không cần thêm dependency
    adviseForState.js             # Orchestrator toàn pipeline: M2 → M3 → M4
  tests/                     # Test cho toàn bộ các module trên (Jest)
  package.json
```

## Cách chạy

Yêu cầu: Node.js >= 18.

```bash
cd backend
npm install
npm test
```

Kỳ vọng: tất cả test suite pass (bao gồm cả `tests/adviseForState.test.js` — test tích hợp
toàn bộ 4 module, dùng LLM client **giả lập**, không gọi mạng, không cần API key).

> `tests/loadCatalog.test.js` và các test tích hợp đọc trực tiếp
> `backend/data/Spec_cate_gia.xlsx` (đã có sẵn trong repo), không cần cấu hình gì thêm.

## Cấu hình API key LLM (Milestone 4)

Milestone 4 là nơi duy nhất trong pipeline thật sự gọi LLM ngoài (để diễn giải Top N sản
phẩm đã lọc/rank). Client không hardcode bất kỳ key nào — bạn tự cấu hình:

```bash
cd backend
cp .env.example .env
# Mở .env, điền LLM_API_KEY=<key thật của bạn>
```

Mặc định `.env.example` đã trỏ tới Anthropic Messages API (`model=claude-sonnet-4-6`).
Nếu bạn dùng model/provider khác có API tương thích `/v1/messages`, chỉnh `LLM_MODEL` và
`LLM_BASE_URL` trong `.env` cho phù hợp.

Sau khi có `.env`, gọi pipeline đầy đủ (ví dụ trong Node REPL hoặc route Express bạn tự nối):

```js
const { createConversationState } = require('./src/state/conversationState');
const { processTurn } = require('./src/turn');
const { adviseForState } = require('./src/adviseForState');

let state = createConversationState('demo-session');
let turn = processTurn(state, { category: 'máy lạnh', budget: '20 triệu', area: '18m2', location: 'phòng ngủ' });
state = turn.state;

// turn.status === 'ready' -> đủ slot, gọi tiếp pipeline retrieval/ranking/explanation
const result = await adviseForState(state); // dùng LLM client thật (đọc .env)
console.log(result.status, result.items);
```

Trong test/CI, KHÔNG cần `.env` — mọi test gọi `adviseForState`/`generateExplanation` đều
truyền `options.llmClient` giả lập để không phụ thuộc mạng hay API key thật.

## Trạng thái triển khai

- ✅ **Milestone 1 — Slot-filling & Conversation State**: canonical NLU, chuẩn hoá
  `location → installation_location`, merge state qua nhiều lượt, tính `missing_slots`
  bằng code, chống hỏi lặp câu hỏi làm rõ, không âm thầm bỏ field sai/không nhận diện được.
- ✅ **Milestone 2 — Retrieval/Filter**: nạp & chuẩn hoá catalog thật từ Excel, lọc sản
  phẩm bằng code theo slot đã đủ, tự động nới ràng buộc theo trình tự định trước khi lọc
  ra 0 kết quả, báo rõ khi không có dữ liệu phù hợp thay vì bịa sản phẩm.
- ✅ **Milestone 3 — Ranking/Explanation (phần rule-based)**: `rankProducts` chấm điểm
  0–100 theo từng tiêu chí (ngân sách, diện tích/số người, độ ồn, ưu tiên tiết kiệm điện...),
  chọn Top N, gắn `matched_reasons`/`tradeoffs`/`missing_data`/`source` — hoàn toàn bằng code.
- ✅ **Milestone 4 — Validation/Guardrail**: gọi LLM diễn giải Top N (API key ngoài do bạn
  tự cấu hình), sau đó đối chiếu từng claim số (giá, m², dB, lít, người) với record gốc —
  loại sản phẩm ngoài Top N, thay claim sai lệch bằng cảnh báo an toàn, giữ lại sản phẩm hợp
  lệ dù LLM bỏ sót, gắn `data_source` vào mọi item trả về.

Chi tiết kiến trúc đầy đủ (4 module, API contract, product schema, user flow, contract của
từng milestone) xem tại [`docs/technical-spec.md`](docs/technical-spec.md).
